### Hexlet tests and linter status:
[![Actions Status](https://github.com/Dron-N-82/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Dron-N-82/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/dfccce44500e52143fdc/maintainability)](https://codeclimate.com/github/Dron-N-82/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/TardnTD6dAmBiWXl9eoBAJkIS.svg)](https://asciinema.org/a/TardnTD6dAmBiWXl9eoBAJkIS)

[![asciicast](https://asciinema.org/a/sPJR6fGODrs0bbio0pp1cbA4e.svg)](https://asciinema.org/a/sPJR6fGODrs0bbio0pp1cbA4e)
